package ro.ase.cts.Isar.Cosmina.Grupa1073.DesignPatterns;

public interface IMotocicleta {
	
	public abstract void afisareMotocicletaConcurs();

}
