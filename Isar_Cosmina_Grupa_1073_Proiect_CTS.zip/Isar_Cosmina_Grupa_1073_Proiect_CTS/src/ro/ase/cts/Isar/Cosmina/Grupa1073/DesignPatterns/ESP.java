package ro.ase.cts.Isar.Cosmina.Grupa1073.DesignPatterns;

public class ESP {
	
	protected boolean areESP = true;
	
	public void adaugaESP() {
		this.areESP = true;
	}
	
	public void eliminaESP() {
		this.areESP = false;
	}

}
