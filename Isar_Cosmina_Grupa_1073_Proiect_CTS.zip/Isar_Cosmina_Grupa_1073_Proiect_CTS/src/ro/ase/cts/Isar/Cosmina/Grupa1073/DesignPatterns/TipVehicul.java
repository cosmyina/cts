package ro.ase.cts.Isar.Cosmina.Grupa1073.DesignPatterns;

public enum TipVehicul {
	AUTOTURISM, MOTOCICLETA, AUTOCAMION
}
